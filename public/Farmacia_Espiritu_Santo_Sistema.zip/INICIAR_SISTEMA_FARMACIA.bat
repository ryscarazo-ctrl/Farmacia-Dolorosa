@echo off
title FARMACIA ESPIRITU SANTO - SUCURSAL 19 DE JULIO
color 0A
echo =====================================================================
echo           SISTEMA FARMACIA ESPIRITU SANTO - SUCURSAL 19 DE JULIO
echo           ABRIENDO SISTEMA EN SU DOMINIO OFICIAL WEB
echo =====================================================================
echo.
echo  DOMINIO OFICIAL: https://farmacia-espiritusanto.vercel.app
echo.
echo  Abriendo navegador web...
start https://farmacia-espiritusanto.vercel.app
echo.
echo  SISTEMA CONECTADO CORRECTAMENTE.
timeout /t 3 >nul
exit

@echo off
title INSTALADOR Y CONFIGURADOR - FARMACIA ESPIRITU SANTO (LAPTOP LOCAL)
color 0A
echo =====================================================================
echo    INSTALADOR RAPIDO PARA LAPTOP LOCAL - FARMACIA ESPIRITU SANTO
echo =====================================================================
echo.

cd /d "%~dp0"

echo [1/3] Verificando instalacion de Node.js en esta laptop...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo.
    echo [!] ATENCION: Node.js no esta instalado en esta laptop.
    echo [!] Se abrira la pagina oficial para descargarlo gratis (Version LTS recomendada).
    echo.
    start https://nodejs.org/
    echo Despues de instalar Node.js, vuelva a ejecutar este archivo.
    pause
    exit /b 1
)

echo [OK] Node.js detectado correctamente.
echo.
echo [2/3] Preparando y verificando librerias del sistema (frontend)...
cd frontend
call npm install --no-audit --no-fund

echo.
echo [3/3] Compilando sistema optimizado para uso local...
call npm run build

echo.
echo =====================================================================
echo   INSTALACION COMPLETA Y EXITOSA
echo =====================================================================
echo.
echo Iniciando el sistema en esta laptop...
start http://localhost:3000

echo.
echo No cierre esta ventana mientras use el sistema en la farmacia.
call npm run start
pause

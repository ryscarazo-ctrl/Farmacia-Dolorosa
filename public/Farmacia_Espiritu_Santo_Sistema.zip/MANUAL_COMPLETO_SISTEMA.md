# 🕊️ MANUAL MAESTRO DEL SISTEMA INTEGRAL
## FARMACIA ESPÍRITU SANTO — SUCURSAL 19 DE JULIO

Bienvenido al manual operativo oficial del **Sistema Integral de Gestión Farmacéutica**. Este documento detalla cada uno de los **24 módulos**, pantallas y funciones del sistema, explicando exactamente **qué es, para qué sirve, quién lo utiliza y el procedimiento paso a paso**.

---

## 📑 ÍNDICE GENERAL DE MÓDULOS

1. [Panel Principal (Dashboard / Resumen Ejecutivo)](#1-panel-principal-dashboard)
2. [Punto de Venta (POS / Facturación en Mostrador)](#2-punto-de-venta-pos)
3. [Historial de Ventas & Reimpresión de Tickets](#3-historial-de-ventas)
4. [Módulo de Devoluciones & Cuarentena](#4-módulo-de-devoluciones--cuarentena)
5. [Directorio de Clientes](#5-directorio-de-clientes)
6. [Ingreso de Nuevos Medicamentos (+ Registro)](#6-ingreso-de-nuevos-medicamentos)
7. [Catálogo de Medicamentos & Inventario General](#7-catálogo-de-medicamentos--inventario)
8. [Control de Lotes & Trazabilidad](#8-control-de-lotes--trazabilidad)
9. [Semáforo de Vencimientos (Protocolo FEFO)](#9-semáforo-de-vencimientos-fefo)
10. [Kárdex & Movimientos de Inventario](#10-kárdex--movimientos-de-inventario)
11. [Transferencias entre Sucursales](#11-transferencias-entre-sucursales)
12. [Compras & Facturas de Proveedores](#12-compras--facturas-de-proveedores)
13. [Directorio de Proveedores & Droguerías](#13-directorio-de-proveedores)
14. [Portal B2B para Proveedores Externos](#14-portal-b2b-para-proveedores)
15. [Arqueo, Turnos y Cierre de Caja (Corte Z)](#15-arqueo-y-cierre-de-caja-corte-z)
16. [Conciliación Bancaria Inteligente](#16-conciliación-bancaria)
17. [Gastos Operativos (OPEX) & Egresos](#17-gastos-operativos-opex)
18. [Margen de Ganancias & Utilidad Neta Real](#18-margen-de-ganancias--utilidades)
19. [Valoración de Inventario (Costo vs. Venta)](#19-valoración-de-inventario)
20. [Reportes de Auditoría & Registro de Actividad](#20-reportes-de-auditoría)
21. [Administración de Sucursales](#21-administración-de-sucursales)
22. [Gestión de Usuarios, Claves & Roles de Seguridad](#22-gestión-de-usuarios-y-roles)
23. [Copias de Seguridad (Backup & Restauración JSON)](#23-copias-de-seguridad-backup)
24. [Configuración General & Moneda](#24-configuración-general)

---

## 1. PANEL PRINCIPAL (DASHBOARD)
* **¿Qué es?** Es la pantalla inicial de bienvenida y centro de mando.
* **¿Para qué sirve?** Permite a la dueña o administradora ver de un solo vistazo el estado de la farmacia sin tener que buscar en múltiples reportes.
* **Indicadores clave que muestra:**
  * **Ventas del Día:** Total recaudado hoy.
  * **Alertas Críticas:** Cantidad de medicamentos próximos a caducar o con stock bajo.
  * **Turno de Caja Actual:** Indica si la caja está abierta o cerrada y quién está cobrando.
  * **Accesos Rápidos:** Botones directos a Cobrar en POS, Ingresar Medicamento y Arqueo.

---

## 2. PUNTO DE VENTA (POS)
* **¿Qué es?** La caja registradora digital para vender y despachar medicamentos en el mostrador.
* **¿Para qué sirve?** Cobrar rápido, evitar equivocaciones de vuelto y descontar del inventario el lote exacto.
* **Funciones principales:**
  * **Lector de Código de Barras:** Al escanear la caja del medicamento, se agrega instantáneamente al carrito.
  * **Buscador Manual:** Si el lector no funciona, escribe el nombre (ej: *Acetaminofén*) o principio activo.
  * **Despacho Automático FEFO:** El sistema siempre selecciona el lote que vence más pronto para que no se quede rezagado.
  * **Aplicación de Descuentos:** Descuento por porcentaje o monto fijo autorizado.
  * **Calculadora de Vuelto:** Ingresas el billete con el que paga el cliente y te dice exactamente cuánto cambio entregar.
  * **Impresión de Ticket Térmico:** Emite comprobante con el nombre del negocio, sucursal, productos y código de lote.

---

## 3. HISTORIAL DE VENTAS
* **¿Qué es?** Registro cronológico de todos los tickets emitidos en la farmacia.
* **¿Para qué sirve?** Consultar ventas pasadas, verificar si un cliente pagó con tarjeta o efectivo, y reimprimir tickets extraviados.
* **Funciones:**
  * Filtro por fecha, cliente, número de ticket y vendedor.
  * Botón para **Reimprimir Ticket**.
  * Botón directo para iniciar una **Devolución** sobre ese ticket.

---

## 4. MÓDULO DE DEVOLUCIONES & CUARENTENA
* **¿Qué es?** Sistema de control para cuando un cliente o paciente regresa un medicamento.
* **¿Para qué sirve?** Garantizar la seguridad médica y registrar por qué motivo salió o entró dinero.
* **Funciones:**
  * **Justificación Obligatoria:** Exige seleccionar el motivo (medicamento en mal estado, error de receta médica, cambio por otra marca o caducado).
  * **Separación Automática:** 
    * Si el empaque está intacto $\rightarrow$ regresa a stock vendible.
    * Si está dañado o vencido $\rightarrow$ se envía a **Cuarentena / Merma**, bloqueándolo de por vida para que nadie lo vuelva a vender.

---

## 5. DIRECTORIO DE CLIENTES
* **¿Qué es?** Base de datos de clientes frecuentes y pacientes con recetas periódicas.
* **¿Para qué sirve?** Guardar nombres, teléfonos, direcciones y asignar créditos o promociones especiales.

---

## 6. INGRESO DE NUEVOS MEDICAMENTOS
* **¿Qué es?** Formulario de alta para registrar productos en el catálogo.
* **¿Para qué sirve?** Dar de alta cualquier jarabe, tableta, inyectable o suplemento nuevo que llegue a la farmacia.
* **Campos obligatorios:**
  * Nombre comercial y Principio activo.
  * Código de barras (EAN-13 o manual).
  * Laboratorio (Vijosa, Bayer, Pfizer, MK, etc.) y Categoría médica.
  * Costo de compra ($) y Precio de venta al público ($).
  * Lote inicial y fecha exacta de vencimiento.
  * Nivel de Stock Mínimo de Alerta.

---

## 7. CATÁLOGO DE MEDICAMENTOS & INVENTARIO
* **¿Qué es?** La lista completa de todos los productos existentes en la farmacia.
* **¿Para qué sirve?** Consultar precios, buscar medicamentos sustitutos por principio activo, modificar precios y exportar la lista a **Excel** o **PDF**.

---

## 8. CONTROL DE LOTES & TRAZABILIDAD
* **¿Qué es?** Panel que desglosa el stock no solo por producto, sino por cada caja y lote individual.
* **¿Para qué sirve?** Saber exactamente cuántas cajas quedan de cada lote y cuándo vence cada una, cumpliendo con las normas de salud.

---

## 9. SEMÁFORO DE VENCIMIENTOS (FEFO)
* **¿Qué es?** Tablero de control de caducidades First-Expired, First-Out.
* **¿Para qué sirve?** Cero pérdidas por vencimiento.
* **Código de colores:**
  * 🟢 **Verde (> 60 días):** Producto seguro y en óptimas condiciones.
  * 🟡 **Amarillo (< 30 días):** Alerta preventiva. Priorizar en mostrador o coordinar canje con el proveedor.
  * 🔴 **Rojo (Vencido):** Bloqueo total. El sistema impide que la cajera lo pueda facturar.

---

## 10. KÁRDEX & MOVIMIENTOS DE INVENTARIO
* **¿Qué es?** El libro contable de entradas y salidas de mercancía.
* **¿Para qué sirve?** Auditoría estricta contra robos o pérdidas. Registra minuto a minuto: quién vendió, quién recibió compras, quién hizo ajustes y el saldo resultante.

---

## 11. TRANSFERENCIAS ENTRE SUCURSALES
* **¿Qué es?** Módulo de envío de medicamentos entre farmacias de la misma empresa.
* **¿Para qué sirve?** Enviar stock desde la sucursal Central (19 de Julio) a otras sucursales (Escalón, Santa Tecla) con emisión de guía de remisión y confirmación de recepción.

---

## 12. COMPRAS & FACTURAS DE PROVEEDORES
* **¿Qué es?** Registro de abastecimiento de mercadería.
* **¿Para qué sirve?** Ingresar las facturas emitidas por las droguerías, actualizar costos automáticamente y sumar los nuevos lotes al stock.

---

## 13. DIRECTORIO DE PROVEEDORES
* **¿Qué es?** Agenda de contactos comerciales.
* **¿Para qué sirve?** Guardar nombres de agentes de ventas, laboratorios, teléfonos, correos y días de visita/entrega.

---

## 14. PORTAL B2B PARA PROVEEDORES EXTERNOS
* **¿Qué es?** Un enlace web público y seguro (`/portal-proveedores`).
* **¿Para qué sirve?** Para que el laboratorio o distribuidor consulte con un código de pedido qué medicamentos necesita la farmacia, confirme si ya los despachó y anote los datos del chofer repartidor.

---

## 15. ARQUEO Y CIERRE DE CAJA (CORTE Z)
* **¿Qué es?** Control de efectivo diario.
* **¿Para qué sirve?** Evitar fugas de dinero.
* **Pasos:**
  1. **Apertura:** Se registra el fondo sencillo (ej: $50.00).
  2. **Durante el turno:** Registra cobros automáticos y salidas de dinero justificadas (ej: $5.00 para compra de agua).
  3. **Cierre (Corte Z):** El cajero cuenta el dinero físico, el sistema lo compara contra el sistema y genera el comprobante de cuadre.

---

## 16. CONCILIACIÓN BANCARIA INTELIGENTE
* **¿Qué es?** Cruce de datos entre el sistema y las cuentas de banco de la farmacia.
* **¿Para qué sirve?** Asegurar que cada cobro hecho con tarjeta de crédito o transferencia bancaria haya ingresado realmente a la cuenta del banco, descontando las comisiones del POS.

---

## 17. GASTOS OPERATIVOS (OPEX)
* **¿Qué es?** Registro de egresos fijos y variables del negocio.
* **¿Para qué sirve?** Anotar facturas de energía eléctrica, agua comercial, alquiler de local, nómina/sueldos, mantenimiento y permisos sanitarios para que el cálculo financiero sea real.

---

## 18. MARGEN DE GANANCIAS & UTILIDADES
* **¿Qué es?** El reporte financiero de rentabilidad neta.
* **¿Para qué sirve?** Responder a la pregunta: *¿Cuánto dinero ganó la farmacia este mes?*
* **Fórmula visual:** `Ventas Totales - Costo de Medicamentos - Gastos OPEX = Utilidad Neta Real`.

---

## 19. VALORACIÓN DE INVENTARIO
* **¿Qué es?** Balance patrimonial del almacén.
* **¿Para qué sirve?** Saber exactamente cuánto dinero en dólares o córdobas hay invertido en medicamentos en los estantes (Costo de adquisición vs. Valor proyectado de venta).

---

## 20. REPORTES DE AUDITORÍA & BITÁCORA
* **¿Qué es?** Registro inalterable de seguridad de eventos del sistema.
* **¿Para qué sirve?** Saber exactamente qué usuario inició sesión, a qué hora modificó un precio, quién eliminó un registro o quién descargó un backup.

---

## 21. ADMINISTRACIÓN DE SUCURSALES
* **¿Qué es?** Configuración multi-sucursal.
* **¿Para qué sirve?** Administrar las diferentes sedes de Farmacia Espíritu Santo (Central 19 de Julio, Sucursal Escalón, Santa Tecla), sus teléfonos y direcciones.

---

## 22. GESTIÓN DE USUARIOS Y ROLES
* **¿Qué es?** Panel de seguridad y permisos de personal.
* **¿Para qué sirve?** Crear usuarios y asignar niveles de acceso:
  * **Administradora (María):** Acceso a todo el sistema, precios y finanzas.
  * **Cajera (Fátima):** Acceso enfocado en vender en el POS y arqueo de caja.

---

## 23. COPIAS DE SEGURIDAD (BACKUP & RESTORE)
* **¿Qué es?** Sistema de respaldo seguro en archivo `.JSON`.
* **¿Para qué sirve?** Blindar los datos de la farmacia. Puedes descargar una copia de toda tu base de datos con un clic y restaurarla en cualquier computadora, tablet o teléfono en segundos.

---

## 24. CONFIGURACIÓN GENERAL & MONEDA
* **¿Qué es?** Parámetros globales del negocio.
* **¿Para qué sirve?** Cambiar el logo oficial, nombre de la farmacia, pie de página del ticket térmico, porcentaje de impuestos y símbolo de moneda (`$` o `C$`).

---

*Manual elaborado con los más altos estándares de calidad técnica y farmacéutica para la Farmacia Espíritu Santo (Sucursal 19 de Julio).*

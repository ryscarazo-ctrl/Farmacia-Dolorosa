'use client';

import React from 'react';
import { 
  Download, 
  Laptop, 
  Globe, 
  ShieldCheck, 
  FileText, 
  Printer, 
  Barcode, 
  CheckCircle2, 
  ArrowRight,
  Sparkles,
  Server,
  Building2,
  PhoneCall
} from 'lucide-react';
import Link from 'next/link';

export default function DescargarPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-emerald-500 selection:text-white">
      {/* Background Glow Overlay */}
      <div className="fixed inset-0 pointer-events-none bg-[radial-gradient(circle_at_top_right,#05966915,transparent_50%)]" />
      <div className="fixed inset-0 pointer-events-none bg-[radial-gradient(circle_at_bottom_left,#0284c715,transparent_50%)]" />

      {/* HEADER NAVBAR */}
      <header className="border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-900/30 ring-1 ring-emerald-400/30">
              <span className="text-2xl">🕊️</span>
            </div>
            <div>
              <h1 className="font-bold text-lg text-white tracking-tight leading-tight">
                Farmacia Espíritu Santo
              </h1>
              <p className="text-xs text-emerald-400 font-medium tracking-wide">
                Sucursal 19 de Julio • Portal de Descargas
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Link 
              href="/" 
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition-all shadow-md shadow-emerald-900/20 flex items-center gap-2"
            >
              <Globe className="w-4 h-4" />
              <span>Abrir Sistema Web</span>
            </Link>
          </div>
        </div>
      </header>

      {/* MAIN CONTENT HERO */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-1">
        
        {/* HERO TITLE BANNER */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-950/80 border border-emerald-500/30 text-emerald-300 text-xs font-semibold mb-6">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Versión de Producción v1.0 • Instalación Offline & Web</span>
          </div>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight mb-4">
            Centro Oficial de Descargas <br />
            <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">
              Farmacia Espíritu Santo
            </span>
          </h2>
          <p className="text-slate-400 text-base sm:text-lg leading-relaxed">
            Descarga el paquete ejecutable para tu laptop de la caja o accede directamente desde cualquier navegador web sin instalar programas adicionales.
          </p>
        </div>

        {/* DOWNLOAD OPTIONS GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          
          {/* OPTION 1: INSTALADOR LOCAL PARA LAPTOP */}
          <div className="relative group rounded-3xl bg-slate-900/90 border border-slate-800 p-8 hover:border-emerald-500/50 transition-all duration-300 shadow-xl hover:shadow-2xl hover:shadow-emerald-950/40 flex flex-col justify-between">
            <div className="absolute top-6 right-6">
              <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold">
                Recomendado para Caja / POS
              </span>
            </div>
            
            <div>
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 mb-6">
                <Laptop className="w-7 h-7" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">
                Paquete Instalador para Laptop Local
              </h3>
              <p className="text-slate-400 text-sm mb-6 leading-relaxed">
                Descarga todo el código pre-compilado listo para ejecutarse en computadoras locales sin necesidad de conexión a internet.
              </p>

              <ul className="space-y-3 mb-8 text-sm text-slate-300">
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Incluye script de inicio rápido 1-clic (`INSTALADOR_LAPTOP_LOCAL.bat`)</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Trazabilidad FEFO, Punto de Venta (POS) y Arqueos locales</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Soporte impresoras térmicas y lector de código de barra USB</span>
                </li>
              </ul>
            </div>

            <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center gap-3">
              <a 
                href="/Farmacia_Espiritu_Santo_Sistema.zip" 
                download
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold text-sm text-center shadow-lg shadow-emerald-900/30 transition-all flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>Descargar Paquete ZIP (1 MB)</span>
              </a>
            </div>
          </div>

          {/* OPTION 2: ACCESO WEB DIRECTO */}
          <div className="relative group rounded-3xl bg-slate-900/90 border border-slate-800 p-8 hover:border-cyan-500/50 transition-all duration-300 shadow-xl hover:shadow-2xl hover:shadow-cyan-950/40 flex flex-col justify-between">
            <div className="absolute top-6 right-6">
              <span className="px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-bold">
                Acceso Nube 24/7
              </span>
            </div>

            <div>
              <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 mb-6">
                <Globe className="w-7 h-7" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">
                Sistema Web en Producción
              </h3>
              <p className="text-slate-400 text-sm mb-6 leading-relaxed">
                Ingresa al sistema en la nube desde cualquier lugar sin instalar ningún archivo. Compatible con laptops, tablets y teléfonos celulares.
              </p>

              <ul className="space-y-3 mb-8 text-sm text-slate-300">
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Dominio seguro HTTPS con cifrado SSL</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Portal B2B para consulta de proveedores</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Sincronización multi-pantalla en tiempo real</span>
                </li>
              </ul>
            </div>

            <div className="pt-4 border-t border-slate-800">
              <Link 
                href="/" 
                className="w-full py-3.5 px-6 rounded-2xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold text-sm text-center border border-cyan-500/30 transition-all flex items-center justify-center gap-2"
              >
                <span>Entrar al Sistema Web Ahora</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

        </div>

        {/* SYSTEM REQUIREMENTS & HARDWARE COMPATIBILITY */}
        <div className="rounded-3xl bg-slate-900/50 border border-slate-800 p-8 mb-12">
          <h4 className="text-xl font-bold text-white mb-6 flex items-center gap-3">
            <ShieldCheck className="w-6 h-6 text-emerald-400" />
            <span>Hardware y Periféricos Compatibles (Sucursal 19 de Julio)</span>
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-800 flex items-start gap-3">
              <Printer className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <h5 className="font-semibold text-white text-sm">Impresora Láser / Térmica</h5>
                <p className="text-xs text-slate-400 mt-1">Canon LBP6030W / LBP6018W & 3nStar Thermal POS 58/80mm</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-800 flex items-start gap-3">
              <Barcode className="w-6 h-6 text-teal-400 shrink-0 mt-0.5" />
              <div>
                <h5 className="font-semibold text-white text-sm">Lectores de Código de Barra</h5>
                <p className="text-xs text-slate-400 mt-1">Soporte universal USB & Bluetooth 1D/2D EAN-13 / GS1</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-800 flex items-start gap-3">
              <Server className="w-6 h-6 text-cyan-400 shrink-0 mt-0.5" />
              <div>
                <h5 className="font-semibold text-white text-sm">Requisitos Mínimos</h5>
                <p className="text-xs text-slate-400 mt-1">Windows 10/11 64-bit, 4 GB RAM, procesador Intel Dual-Core</p>
              </div>
            </div>
          </div>
        </div>

      </main>

      {/* FOOTER */}
      <footer className="border-t border-slate-800/80 bg-slate-900/80 py-8 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-400" />
            <span>Farmacia Espíritu Santo • Sucursal 19 de Julio</span>
          </div>
          <div>
            <span>© 2026 Todos los derechos reservados. Sistema Integral de Gestión Farmacéutica.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

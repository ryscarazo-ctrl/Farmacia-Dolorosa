'use client';

import React, { useState } from 'react';
import {
  BookOpen,
  UserCheck,
  ShieldCheck,
  ShoppingCart,
  HardDrive,
  Printer,
  Search,
  CheckCircle2,
  Lock,
  PackagePlus,
  Layers,
  DollarSign,
  Vault,
  Eye,
  KeyRound,
  Download,
  Upload,
  AlertTriangle,
  Receipt,
  Building,
  Menu,
  Sparkles,
  ArrowRight,
  TrendingUp,
  RotateCcw,
  Truck,
  CreditCard,
  Barcode,
  HelpCircle,
  FileSpreadsheet,
  Users,
  Building2,
  Calendar,
  History,
  Boxes,
  ShieldAlert,
  Coins,
  Check,
  ChevronDown,
  ChevronUp,
  Bookmark,
  ExternalLink,
  Flame,
  Clock,
  AlertCircle,
  FileCheck2,
  ListOrdered,
  HeartHandshake,
  Sun,
  Moon,
  Store,
  BadgeCheck,
  FileText,
  Loader2,
} from 'lucide-react';
import { NavSection } from '../layout/Sidebar';
import jsPDF from 'jspdf';

interface ManualViewProps {
  onNavigate?: (view: NavSection) => void;
}

export const ManualView: React.FC<ManualViewProps> = ({ onNavigate }) => {
  const [selectedScene, setSelectedScene] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  const handlePrint = () => {
    window.print();
  };

  const navigateToSection = (section: NavSection) => {
    if (onNavigate) {
      onNavigate(section);
    }
  };

  const handleDownloadPdf = () => {
    try {
      setIsGeneratingPdf(true);
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      let y = 20;

      // Colores de la marca
      const primaryGreen: [number, number, number] = [6, 78, 59]; // emerald-900
      const accentGreen: [number, number, number] = [16, 185, 129]; // emerald-500
      const darkText: [number, number, number] = [15, 23, 42]; // slate-900
      const grayText: [number, number, number] = [71, 85, 105]; // slate-600

      const checkPageBreak = (neededHeight: number) => {
        if (y + neededHeight > pageHeight - 20) {
          doc.addPage();
          y = 20;
          drawHeaderSmall();
        }
      };

      const drawHeaderSmall = () => {
        doc.setFillColor(...primaryGreen);
        doc.rect(0, 0, pageWidth, 12, 'F');
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(255, 255, 255);
        doc.text('FARMACIA ESPÍRITU SANTO 🕊️ — SUCURSAL 19 DE JULIO | MANUAL OFICIAL DE OPERACIÓN', 14, 8);
        y = 22;
      };

      // ==========================================
      // PORTADA / ENCABEZADO PRINCIPAL (PÁGINA 1)
      // ==========================================
      doc.setFillColor(...primaryGreen);
      doc.roundedRect(12, 14, pageWidth - 24, 38, 4, 4, 'F');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(18);
      doc.setTextColor(255, 255, 255);
      doc.text('MANUAL MAESTRO DE OPERACIÓN Y USUARIO', 18, 28);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(167, 243, 208); // emerald-200
      doc.text('Farmacia Espíritu Santo 🕊️ — Sucursal 19 de Julio (Central)', 18, 36);
      doc.text('Guía Paso a Paso • Protocolo FEFO • Punto de Venta • Finanzas • Arqueo de Caja', 18, 43);

      y = 60;

      // ==========================================
      // SECCIÓN 1: ROLES Y CREDENCIALES
      // ==========================================
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(13);
      doc.setTextColor(...primaryGreen);
      doc.text('1. TABLA OFICIAL DE USUARIOS Y ROLES', 14, y);
      y += 6;

      doc.setDrawColor(203, 213, 225);
      doc.setFillColor(248, 250, 252);
      doc.roundedRect(14, y, pageWidth - 28, 24, 2, 2, 'FD');

      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(...darkText);
      doc.text('• MARÍA TARDENCILLA (Propietaria & Admin):', 18, y + 6);
      doc.setFont('helvetica', 'normal');
      doc.text('Usuario: maria  |  Contraseña: Maria2026*  |  Acceso total a precios, compras, OPEX y bancos.', 18, y + 11);

      doc.setFont('helvetica', 'bold');
      doc.text('• FÁTIMA SELENE (Vendedora & Cajera):', 18, y + 17);
      doc.setFont('helvetica', 'normal');
      doc.text('Usuario: fatima  |  Contraseña: Fatima2026*  |  Acceso a Punto de Venta (POS), cobro y caja.', 18, y + 22);

      y += 32;

      // ==========================================
      // ESCENAS OPERATIVAS PASO A PASO
      // ==========================================
      const scenes = [
        {
          num: 'ESCENA 1 (8:00 AM)',
          title: 'Apertura de Turno y Fondo de Caja',
          desc: 'Al iniciar la mañana, Fátima ingresa al sistema en "Arqueo & Cierre de Caja" y digita el Fondo Inicial de Apertura ($50.00 en sencillo). Esto garantiza que el sistema compare las ventas contra el saldo real sin descuadres.',
          steps: [
            '1. Iniciar sesión con usuario fatima.',
            '2. Ir al menú lateral -> Arqueo & Cierre de Caja.',
            '3. En "Fondo Inicial de Apertura", escribir: 50.00.',
            '4. Presionar el botón verde "Abrir Turno de Caja".',
          ],
        },
        {
          num: 'ESCENA 2 (11:30 AM)',
          title: 'Punto de Venta (POS), FEFO y Vuelto Automático',
          desc: 'Cuando un cliente pide medicamentos, Fátima escanea la caja con el lector láser. El sistema aplica automáticamente la regla FEFO (descuenta el lote que vence más próximo). Al cobrar en efectivo, el sistema calcula el vuelto exacto.',
          steps: [
            '1. Escanear el código de barras de la caja o buscar por nombre.',
            '2. El sistema asigna el lote con vencimiento más próximo.',
            '3. Clic en botón verde COBRAR ($).',
            '4. Digitar el monto recibido (ej: billete de $20).',
            '5. La pantalla muestra el VUELTO EXACTO en números gigantes.',
            '6. Confirmar venta -> Se abre gaveta y se imprime ticket térmico con lote.',
          ],
        },
        {
          num: 'ESCENA 3 (3:15 PM)',
          title: 'Devoluciones y Cuarentena de Medicamentos',
          desc: 'Si un paciente regresa un producto por cambio de receta o daño, el sistema exige un motivo obligatorio. Si la caja está sellada regresa a Stock Vendible; si está rota o vencida pasa a Cuarentena/Merma (bloqueada para siempre).',
          steps: [
            '1. Entrar al menú -> Devoluciones.',
            '2. Escanear el código de barras del medicamento devuelto.',
            '3. Seleccionar motivo: Cambio de receta / Empaque dañado / Caducado.',
            '4. Marcar destino: Stock Disponible (si está óptimo) o Cuarentena (si está dañado).',
            '5. Confirmar devolución y entregar reembolso o nuevo producto.',
          ],
        },
        {
          num: 'ESCENA 4 (4:30 PM)',
          title: 'Recepción de Pedidos de Laboratorios (Vijosa, Bayer, MK)',
          desc: 'Al llegar el camión con nueva mercadería, María da de alta los productos ingresando costo de compra y precio al público. El sistema calcula en vivo el Margen % de ganancia neta.',
          steps: [
            '1. Entrar a + Ingresar Medicamento.',
            '2. Escribir nombre comercial, principio activo y seleccionar laboratorio.',
            '3. Escanear código de barras de la botella/caja.',
            '4. Ingresar Costo ($) y Precio de Venta ($) -> Calcula margen % en vivo.',
            '5. Digitar número de lote, fecha de vencimiento y cantidad.',
            '6. Presionar Guardar Medicamento -> Queda listo para venderse en POS.',
          ],
        },
        {
          num: 'ESCENA 5 (6:00 PM)',
          title: 'Gastos Operativos (OPEX) y Utilidad Neta Real',
          desc: 'María registra las facturas de luz, agua comercial y alquiler del local 19 de Julio. El sistema descuenta estos costos de las ventas para mostrar la Ganancia Neta Real que le queda al negocio.',
          steps: [
            '1. Entrar a Gastos Operativos (OPEX) -> + Registrar Gasto.',
            '2. Seleccionar categoría: Luz, Agua, Alquiler, Sueldos o Limpieza.',
            '3. Ingresar monto ($) y número de recibo.',
            '4. El tablero calcula: Ventas Totales - Costo Medicamentos - Gastos OPEX = Utilidad Neta.',
          ],
        },
        {
          num: 'ESCENA 6 (8:00 PM)',
          title: 'Cierre de Turno (Corte Z) y Copia de Respaldo',
          desc: 'Al terminar la jornada, Fátima realiza el Arqueo Ciego contando el dinero físico en efectivo. El sistema lo compara contra las ventas y emite el Corte Z. María descarga la copia de seguridad semanal.',
          steps: [
            '1. Entrar a Arqueo & Cierre de Caja.',
            '2. Contar todo el dinero en monedas y billetes en gaveta.',
            '3. Digitar el total en "Efectivo Físico en Gaveta ($)".',
            '4. Verificar resultado: Diferencia $0.00 (Cuadre Perfecto).',
            '5. Presionar "Cerrar Turno & Emitir Corte Z" (Se imprime comprobante).',
            '6. Cada viernes: Entrar a Copia de Seguridad -> Descargar Respaldo (.JSON).',
          ],
        },
      ];

      scenes.forEach((s) => {
        checkPageBreak(45);

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(11);
        doc.setTextColor(...primaryGreen);
        doc.text(`${s.num}: ${s.title}`, 14, y);
        y += 5;

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8.5);
        doc.setTextColor(...grayText);
        const splitDesc = doc.splitTextToSize(s.desc, pageWidth - 28);
        doc.text(splitDesc, 14, y);
        y += splitDesc.length * 4 + 2;

        doc.setDrawColor(226, 232, 240);
        doc.setFillColor(248, 250, 252);
        const boxHeight = s.steps.length * 4.2 + 4;
        doc.roundedRect(14, y, pageWidth - 28, boxHeight, 1.5, 1.5, 'FD');

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(...darkText);
        let stepY = y + 4;
        s.steps.forEach((st) => {
          doc.text(st, 18, stepY);
          stepY += 4.2;
        });

        y += boxHeight + 6;
      });

      // Pie de página en todas las páginas
      const totalPages = doc.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(7.5);
        doc.setTextColor(148, 163, 184);
        doc.text(
          `Farmacia Espíritu Santo (Sucursal 19 de Julio) • Documento Oficial de Capacitación • Página ${i} de ${totalPages}`,
          pageWidth / 2,
          pageHeight - 8,
          { align: 'center' }
        );
      }

      doc.save('Manual_Oficial_Farmacia_Espiritu_Santo_19Jul.pdf');
      setIsGeneratingPdf(false);
    } catch (err) {
      console.error('Error generando PDF:', err);
      setIsGeneratingPdf(false);
      alert('Se generó un error al compilar el PDF. Usa la opción Imprimir para guardarlo como PDF del navegador.');
    }
  };

  return (
    <div className="flex-1 p-4 sm:p-6 lg:p-8 space-y-6 overflow-y-auto bg-slate-50 text-slate-800">
      {/* ========================================================================= */}
      {/* HERO BANNER INMERSIVO Y EXPRESIVO */}
      {/* ========================================================================= */}
      <div className="bg-gradient-to-r from-emerald-950 via-teal-950 to-emerald-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl shadow-emerald-950/20 border border-emerald-800/40 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2 text-emerald-300 text-xs font-bold uppercase tracking-wider">
              <span className="bg-emerald-800/90 px-3 py-1 rounded-full border border-emerald-600/50 flex items-center gap-1.5 shadow-sm">
                <HeartHandshake className="w-3.5 h-3.5 text-emerald-300" />
                Vocación de Servicio & Eficiencia Operativa
              </span>
              <span className="text-emerald-400 font-mono text-[11px]">Sucursal 19 de Julio • Guía Maestra</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-black tracking-tight text-white flex items-center gap-2">
              Crónica & Manual de Operación Viva 🕊️
            </h1>
            <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
              La guía completa con el contexto humano, los escenarios reales del mostrador y el procedimiento exacto paso a paso para cuidar la salud de nuestros pacientes y la prosperidad de nuestra farmacia.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            {/* BOTÓN DESCARGAR PDF DIRECTO */}
            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="px-5 py-3 bg-emerald-500 hover:bg-emerald-400 text-emerald-950 rounded-2xl font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-emerald-950/30 cursor-pointer transition-all active:scale-95 border border-emerald-400"
            >
              {isGeneratingPdf ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-emerald-950" />
                  <span>Generando PDF...</span>
                </>
              ) : (
                <>
                  <FileText className="w-4 h-4 text-emerald-950" />
                  <span>Descargar Manual en PDF</span>
                </>
              )}
            </button>

            {/* BOTÓN IMPRIMIR */}
            <button
              type="button"
              onClick={handlePrint}
              className="px-5 py-3 bg-white hover:bg-emerald-50 text-emerald-950 rounded-2xl font-extrabold text-xs sm:text-sm flex items-center gap-2 shadow-lg cursor-pointer transition-all active:scale-95 border border-white"
            >
              <Printer className="w-4 h-4 text-emerald-700" />
              <span>Imprimir</span>
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* NAVEGADOR DE ESCENAS & BUSCADOR INTELIGENTE */}
      {/* ========================================================================= */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm sticky top-0 z-20 backdrop-blur-md bg-white/95">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 lg:pb-0 scrollbar-none">
          <button
            onClick={() => setSelectedScene('all')}
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedScene === 'all'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'bg-slate-100 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Toda la Jornada</span>
          </button>

          <button
            onClick={() => setSelectedScene('escena1')}
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedScene === 'escena1'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'bg-slate-100 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800'
            }`}
          >
            <Sun className="w-3.5 h-3.5 text-amber-500" />
            <span>1. Amanecer & Apertura (8:00 AM)</span>
          </button>

          <button
            onClick={() => setSelectedScene('escena2')}
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedScene === 'escena2'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'bg-slate-100 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800'
            }`}
          >
            <ShoppingCart className="w-3.5 h-3.5 text-emerald-600" />
            <span>2. Mostrador & Cobro Rápido</span>
          </button>

          <button
            onClick={() => setSelectedScene('escena3')}
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedScene === 'escena3'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'bg-slate-100 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5 text-rose-600" />
            <span>3. Devolución & Cuarentena</span>
          </button>

          <button
            onClick={() => setSelectedScene('escena4')}
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedScene === 'escena4'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'bg-slate-100 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800'
            }`}
          >
            <Truck className="w-3.5 h-3.5 text-blue-600" />
            <span>4. Recepción de Pedidos</span>
          </button>

          <button
            onClick={() => setSelectedScene('escena5')}
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedScene === 'escena5'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'bg-slate-100 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 text-emerald-700" />
            <span>5. Gastos & Rentabilidad (María)</span>
          </button>

          <button
            onClick={() => setSelectedScene('escena6')}
            className={`px-3.5 py-2 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedScene === 'escena6'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'bg-slate-100 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800'
            }`}
          >
            <Moon className="w-3.5 h-3.5 text-indigo-500" />
            <span>6. Cierre Z & Backup (8:00 PM)</span>
          </button>
        </div>

        <div className="relative min-w-[260px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por paciente, vuelto, FEFO, arqueo..."
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-3.5 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-emerald-500 focus:bg-white font-medium shadow-inner"
          />
        </div>
      </div>

      {/* ========================================================================= */}
      {/* ESCENA 1: EL AMANECER & APERTURA DE CAJA */}
      {/* ========================================================================= */}
      {(selectedScene === 'all' || selectedScene === 'escena1') && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-sm space-y-4 animate-fade-in">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-amber-100 text-amber-800 rounded-2xl shadow-xs">
                <Sun className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider">Escena 1 • 8:00 AM</span>
                <h2 className="font-black text-lg sm:text-xl text-slate-900">
                  El Amanecer en la Farmacia: Apertura de Turno y Fondo de Caja
                </h2>
              </div>
            </div>
            <button
              onClick={() => navigateToSection('cash')}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all shadow-md shadow-amber-600/20 cursor-pointer"
            >
              <span>Ir al Módulo de Caja</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-2xl text-xs text-slate-700 leading-relaxed space-y-2">
            <p>
              <strong>🎭 El Contexto Real:</strong> Fátima llega a la Sucursal 19 de Julio, enciende las luces y recibe de María la gaveta con <strong>$50.00 en monedas y billetes sencillos</strong> para dar cambio. Si no se registra este dinero inicial, al final del día parecerá falsamente que "sobró dinero" en el arqueo.
            </p>
          </div>

          <div className="space-y-3 text-xs">
            <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
              <BadgeCheck className="w-4 h-4 text-emerald-600" />
              Procedimiento Operativo Paso a Paso:
            </h3>
            <ol className="list-decimal list-inside space-y-2 text-slate-700 leading-relaxed pl-1 font-medium">
              <li>Inicia sesión con tu usuario <code className="bg-slate-100 px-1.5 py-0.5 rounded font-bold text-emerald-800 border">fatima</code> y clave <code className="bg-slate-100 px-1.5 py-0.5 rounded font-bold text-emerald-800 border">fatima2026</code>.</li>
              <li>En el menú lateral, haz clic en <strong>Arqueo & Cierre de Caja</strong> (ícono de caja fuerte).</li>
              <li>En la casilla <strong>Fondo Inicial de Apertura ($)</strong>, escribe exactamente: <code className="bg-white px-2 py-0.5 rounded font-bold text-slate-900 border">50.00</code>.</li>
              <li>En notas escribe: <em>"Apertura matutina - Fátima Selene"</em>.</li>
              <li>Haz clic en el botón verde <strong>Abrir Turno de Caja</strong>.</li>
              <li><span className="text-emerald-800 font-bold">✨ Resultado:</span> El sistema queda desbloqueado y cada cobro sumará en tiempo real al saldo de la gaveta.</li>
            </ol>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* ESCENA 2: VENTA RÁPIDA Y PROTOCOLO FEFO */}
      {/* ========================================================================= */}
      {(selectedScene === 'all' || selectedScene === 'escena2') && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-sm space-y-5 animate-fade-in">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-emerald-100 text-emerald-800 rounded-2xl shadow-xs">
                <ShoppingCart className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider">Escena 2 • 11:30 AM</span>
                <h2 className="font-black text-lg sm:text-xl text-slate-900">
                  La Hora Pico en Mostrador: Escaneo Láser, FEFO Automático y Vuelto Exacto
                </h2>
              </div>
            </div>
            <button
              onClick={() => navigateToSection('pos')}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all shadow-md shadow-emerald-600/20 cursor-pointer"
            >
              <span>Abrir Punto de Venta (POS)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl text-xs text-slate-700 leading-relaxed space-y-2">
            <p>
              <strong>🎭 El Contexto Real:</strong> Llega Don Roberto con una receta para la fiebre de su hijo. Hay fila en el mostrador. Fátima necesita atenderlo con rapidez y sin margen de error al dar el vuelto.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            {/* Paso A */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
              <span className="font-black text-slate-900 text-sm flex items-center gap-1.5">
                <Barcode className="w-4 h-4 text-emerald-600" />
                1. Escanear Caja
              </span>
              <p className="text-slate-600 leading-relaxed">
                Toma la caja del estante y pasa el láser por el código de barras $\rightarrow$ <strong>¡Bip!</strong> Se agrega al carrito. El sistema selecciona el lote que vence más pronto (FEFO) para evitar mermas.
              </p>
            </div>

            {/* Paso B */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
              <span className="font-black text-slate-900 text-sm flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-emerald-600" />
                2. Cobrar & Vuelto
              </span>
              <p className="text-slate-600 leading-relaxed">
                Total: \$12.50. Don Roberto paga con billete de \$20. Digitas <code>20</code> y la pantalla te muestra en grande: <strong>"Vuelto exacto: $7.50"</strong>. Cero cálculos mentales erróneos.
              </p>
            </div>

            {/* Paso C */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
              <span className="font-black text-slate-900 text-sm flex items-center gap-1.5">
                <Receipt className="w-4 h-4 text-emerald-600" />
                3. Ticket Térmico
              </span>
              <p className="text-slate-600 leading-relaxed">
                Presionas <strong>Confirmar Venta</strong>. Se abre la gaveta de dinero y se imprime el comprobante con los datos de la sucursal 19 de Julio, lote y desglose legal.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* ESCENA 3: DEVOLUCIONES & CUARENTENA */}
      {/* ========================================================================= */}
      {(selectedScene === 'all' || selectedScene === 'escena3') && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-sm space-y-5 animate-fade-in">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-rose-100 text-rose-800 rounded-2xl shadow-xs">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-rose-700 uppercase tracking-wider">Escena 3 • 3:15 PM</span>
                <h2 className="font-black text-lg sm:text-xl text-slate-900">
                  Devolución Justificada: Protección Médica al Paciente y Cuarentena
                </h2>
              </div>
            </div>
            <button
              onClick={() => navigateToSection('returns')}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all shadow-md shadow-rose-600/20 cursor-pointer"
            >
              <span>Abrir Devoluciones</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="p-4 bg-rose-50/70 border border-rose-200 rounded-2xl text-xs text-slate-700 leading-relaxed space-y-2">
            <p>
              <strong>🎭 El Contexto Real:</strong> Una paciente regresa porque el médico le modificó la receta. Trae una caja de pastillas intacta. Fátima debe registrar la devolución de forma obligatoria para que el inventario cuadre y la salud no se ponga en riesgo.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-2xl space-y-2">
              <span className="font-black text-emerald-950 text-sm">🟢 Caja Intacta y Sellada:</span>
              <p className="text-slate-700 leading-relaxed">
                Selecciona <strong>Motivo $\rightarrow$ Cambio de Receta</strong> y marca <strong>Destino $\rightarrow$ Stock Disponible</strong>. El medicamento regresa al estante para dispensarse a otro paciente.
              </p>
            </div>

            <div className="bg-rose-50 border border-rose-200 p-4 rounded-2xl space-y-2">
              <span className="font-black text-rose-950 text-sm">🔴 Caja Dañada o Vencida:</span>
              <p className="text-slate-700 leading-relaxed">
                Marca <strong>Destino $\rightarrow$ Cuarentena / Merma</strong>. El sistema bloquea el producto de forma definitiva para que jamás pueda ser revendido por descuido.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* ESCENA 4: RECEPCIÓN DE PEDIDOS DROGUERÍA */}
      {/* ========================================================================= */}
      {(selectedScene === 'all' || selectedScene === 'escena4') && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-sm space-y-5 animate-fade-in">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-100 text-blue-800 rounded-2xl shadow-xs">
                <Truck className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-blue-700 uppercase tracking-wider">Escena 4 • 4:30 PM</span>
                <h2 className="font-black text-lg sm:text-xl text-slate-900">
                  Llegada del Camión Distribuidor: Alta Rápida y Margen de Utilidad
                </h2>
              </div>
            </div>
            <button
              onClick={() => navigateToSection('new-product')}
              className="px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all shadow-md shadow-blue-700/20 cursor-pointer"
            >
              <span>+ Ingresar Medicamento</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="p-4 bg-blue-50/70 border border-blue-200 rounded-2xl text-xs text-slate-700 leading-relaxed space-y-2">
            <p>
              <strong>🎭 El Contexto Real:</strong> Se estaciona el camión de Laboratorios Vijosa con 72 frascos de Suero Oral. María ingresa la factura comercial al sistema en 1 minuto.
            </p>
          </div>

          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 text-xs space-y-2">
            <h3 className="font-black text-slate-900 text-sm">Pasos para dar de alta en el sistema:</h3>
            <ol className="list-decimal list-inside space-y-1.5 text-slate-700 leading-relaxed font-medium">
              <li>Abre <strong>+ Ingresar Medicamento</strong>.</li>
              <li>Escribe: <em>Suero Oral Electrolitos Vijosa 500ml</em> y principio activo: <em>Sales de Rehidratación Oral</em>.</li>
              <li>Escanea el código de barras de la botella.</li>
              <li>Escribe el Costo: <code className="bg-white px-1.5 py-0.5 rounded font-bold border">$1.10</code> y Precio al Público: <code className="bg-white px-1.5 py-0.5 rounded font-bold border">$1.85</code> *(Margen automático: 40.5%)*.</li>
              <li>Digita el Lote: <code className="bg-white px-1.5 py-0.5 rounded font-bold border">LOTE-VIJ-2026-09</code> y la fecha de caducidad: <code className="bg-white px-1.5 py-0.5 rounded font-bold border">2028-11-30</code>.</li>
              <li>Ingresa la cantidad: <code>72</code> y presiona <strong>Guardar Medicamento</strong>.</li>
            </ol>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* ESCENA 5: GASTOS OPEX Y GANANCIAS */}
      {/* ========================================================================= */}
      {(selectedScene === 'all' || selectedScene === 'escena5') && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-sm space-y-5 animate-fade-in">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-emerald-100 text-emerald-800 rounded-2xl shadow-xs">
                <TrendingUp className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider">Escena 5 • 6:00 PM</span>
                <h2 className="font-black text-lg sm:text-xl text-slate-900">
                  La Visión de María: Gastos Operativos (OPEX) y Utilidad Neta Real
                </h2>
              </div>
            </div>
            <button
              onClick={() => navigateToSection('operational-expenses')}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all shadow-md shadow-emerald-700/20 cursor-pointer"
            >
              <span>Ver Gastos OPEX</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl text-xs text-slate-700 leading-relaxed space-y-2">
            <p>
              <strong>🎭 El Contexto Real:</strong> María registra la factura de energía eléctrica (\$120.00 por el consumo de las refrigeradoras de vacunas). El sistema calcula la <strong>Utilidad Neta Real</strong>:
            </p>
            <div className="p-3 bg-white rounded-xl border border-emerald-300 font-mono text-center font-black text-emerald-900 text-xs sm:text-sm">
              Ventas Totales ($8,500) − Costo Medicamentos ($5,100) − Gastos OPEX ($1,200) = Ganancia Neta ($2,200)
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* ESCENA 6: CIERRE Z & BACKUP */}
      {/* ========================================================================= */}
      {(selectedScene === 'all' || selectedScene === 'escena6') && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-sm space-y-5 animate-fade-in">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-indigo-100 text-indigo-800 rounded-2xl shadow-xs">
                <Moon className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-indigo-700 uppercase tracking-wider">Escena 6 • 8:00 PM</span>
                <h2 className="font-black text-lg sm:text-xl text-slate-900">
                  Cierre de la Jornada: Arqueo Ciego, Corte Z y Copia de Seguridad
                </h2>
              </div>
            </div>
            <button
              onClick={() => navigateToSection('cash')}
              className="px-4 py-2 bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all shadow-md shadow-indigo-700/20 cursor-pointer"
            >
              <span>Cerrar Turno (Corte Z)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-2">
              <span className="font-black text-slate-900 text-sm flex items-center gap-1.5">
                <Vault className="w-4 h-4 text-emerald-600" />
                Arqueo Ciego (Transparencia Total):
              </span>
              <p className="text-slate-600 leading-relaxed">
                Fátima cuenta los billetes en la gaveta y digita: <code>540.00</code>. El sistema compara contra el esperado y muestra: <strong className="text-emerald-700">DIFERENCIA: $0.00 (CUADRE PERFECTO)</strong>. Se imprime el Corte Z.
              </p>
            </div>

            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-2">
              <span className="font-black text-slate-900 text-sm flex items-center gap-1.5">
                <HardDrive className="w-4 h-4 text-teal-600" />
                Copia de Respaldo Semanal (.JSON):
              </span>
              <p className="text-slate-600 leading-relaxed">
                María entra a <strong>Copia de Seguridad</strong> y presiona <strong>Descargar Backup (.JSON)</strong> para guardarlo en una memoria USB. Toda la información queda protegida contra fallos eléctricos o cambios de equipo.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
